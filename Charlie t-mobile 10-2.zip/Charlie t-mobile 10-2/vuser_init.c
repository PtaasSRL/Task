int nIterationNumber = 1;

vuser_init()
{
	return 0;
}
